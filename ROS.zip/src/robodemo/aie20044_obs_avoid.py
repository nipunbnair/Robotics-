#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
def scan_callback(msg):
    if msg.ranges[0] > 0.6 and msg.ranges[35]>0.6 and msg.ranges[325]>0.6:
        cmd_vel_pub.publish(start)
        print("normal")
    elif msg.ranges[0]< 0.4 or msg.ranges[35]<0.4 or msg.ranges[325]<0.4:
        cmd_vel_pub.publish(reverse)
        print("reversing")
    else:
        cmd_vel_pub.publish(turn)
        print("turning")
    range_ahead = msg.ranges[0]
    print ("range ahead: %0.1f" % range_ahead)
cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
rospy.init_node('wanderer')
turn = Twist()
start = Twist()
reverse = Twist()
start.linear.x= 0.2
reverse.linear.x= -0.2
turn.angular.z=0.55
rate = rospy.Rate(10)
scan_sub = rospy.Subscriber('scan', LaserScan, scan_callback)
rospy.spin()
