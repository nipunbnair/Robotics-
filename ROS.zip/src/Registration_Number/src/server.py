#!/usr/bin/env python3
import rospy 
from Registration_Number.srv import FullReg 
from Registration_Number.srv import FullRegResponse
def reg_no(request):
    full_rollno="BL.EN.U4"+request.dept+request.num
    print("Responded [full_rollno:%s]" %full_rollno)
    return FullRegResponse(full_rollno)

def registration_number():
    rospy.init_node('registration_number')
    service = rospy.Service('reg_no', FullReg, reg_no)
    print("Ready to print regno")
    rospy.spin()
    
if __name__ == '__main__':
   try:
   	registration_number()
   except rospy.ROSInterruptException:
   	pass
