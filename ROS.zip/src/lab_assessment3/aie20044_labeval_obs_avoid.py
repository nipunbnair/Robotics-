#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
def scan_callback(msg):
    if msg.ranges[0] > 1 and msg.ranges[35]>1 and msg.ranges[325]>1:
        cmd_vel_pub.publish(start)
        print("normal")
    elif msg.ranges[0]< 1 :
        cmd_vel_pub.publish(lturn)
        print("turning left")
        cmd_vel_pub.publish(start)
        print("straight")
    elif msg.ranges[35]< 1 :
        cmd_vel_pub.publish(stop)
        print("stopping")
    elif msg.ranges[325]< 1 :
        cmd_vel_pub.publish(rturn)
        print("turning right")
        cmd_vel_pub.publish(reverse)
        print("reverse")      
    else:
        cmd_vel_pub.publish(stop)
        print("stop")
    range_ahead = msg.ranges[0]
    print ("range ahead: %0.1f" % range_ahead)
cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
rospy.init_node('wanderer')
rturn = Twist()
lturn = Twist()
start = Twist()
reverse = Twist()
stop = Twist()
stop.linear=0
stop.angular=0
start.linear.x= 0.2
reverse.linear.x= -0.2
rturn.angular.z=0.55
lturn.angular.z=-0.55
rate = rospy.Rate(10)
scan_sub = rospy.Subscriber('scan', LaserScan, scan_callback)
rospy.spin()
