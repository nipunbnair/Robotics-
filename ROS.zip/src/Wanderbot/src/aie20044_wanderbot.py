#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
def scan_callback(msg):
    if msg.ranges[0] > 1.2:
        cmd_vel_pub.publish(start)
    elif msg.ranges[0] < 0.4:
        cmd_vel_pub.publish(reverse)
    else:
        cmd_vel_pub.publish(turn)
    rate.sleep()
    range_ahead = msg.ranges[0]
    print ("range ahead: %0.1f" % range_ahead)
cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
rospy.init_node('wanderer')
turn = Twist()
start = Twist()
reverse = Twist()
start.linear.x= 1
reverse.linear.x= -0.1
turn.angular.z=3.14/4
rate = rospy.Rate(10)
scan_sub = rospy.Subscriber('scan', LaserScan, scan_callback)
rospy.spin()
