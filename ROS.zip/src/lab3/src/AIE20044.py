#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
def move():
    move_pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    pose_sub = rospy.Subscriber('turtle1/pose', Pose, pose_callback)
    rospy.init_node('turtle_move', anonymous=True)
    rate = rospy.Rate(1)
    vel_twist = Twist()
    vel_twist.linear.y =1
    vel_twist.linear.x=0
    move_pub.publish(vel_twist)
    rate.sleep()
    vel_twist = Twist()
    vel_twist.linear.x =0
    vel_twist.linear.y =1
    move_pub.publish(vel_twist)
    rate.sleep()
    vel_twist.linear.y =0
    vel_twist.linear.x=1
    move_pub.publish(vel_twist)
    rate.sleep()
    vel_twist = Twist()
    vel_twist.linear.x =0
    vel_twist.linear.y =-1
    move_pub.publish(vel_twist)
    rate.sleep()
    vel_twist = Twist()
    vel_twist.linear.y =0
    vel_twist.linear.x=-1
    move_pub.publish(vel_twist)
    rate.sleep()
def pose_callback(message):
    print ("X position:%f\tY position:%f\tTheta:%f\t"%(message.x, message.y, message.theta))
if __name__ == '__main__':
     try:
         move()
     except rospy.ROSInterruptException:
         pass
