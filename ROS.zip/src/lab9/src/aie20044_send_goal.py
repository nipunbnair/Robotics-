#!/usr/bin/env python3
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import *
rospy.init_node('send_goal')
ac = actionlib.SimpleActionClient('move_base', MoveBaseAction)
ac.wait_for_server()
goal = MoveBaseGoal()
goal.target_pose.header.frame_id = "map"
goal.target_pose.header.stamp = rospy.Time.now()
goal.target_pose.pose.position.x = int(input("Enter position of x: "))
goal.target_pose.pose.position.y = int(input("Enter position of y: "))
goal.target_pose.pose.position.z = 0
goal.target_pose.pose.orientation.x = 0
goal.target_pose.pose.orientation.y = 0
goal.target_pose.pose.orientation.z = float(input("Enter orientation of z: "))
goal.target_pose.pose.orientation.w = 1
print("Sending Goal Location...")
ac.send_goal(goal)
