#!/usr/bin/env python3
import rospy
from turtlesim.srv import TeleportAbsolute
import sys
def client_val(in1,in2,in3):
    rospy.init_node('client')
    rospy.wait_for_service('/turtle1/teleport_absolute')
    inputval = rospy.ServiceProxy('/turtle1/teleport_absolute', TeleportAbsolute)
    val4= inputval(float(in1),float(in2),float(in3))
if __name__ == '__main__':
    if len(sys.argv )== 4:
            val1 = sys.argv[1]
            val2 = sys.argv[2]
            val3 = sys.argv[3]
    else:
        print("%s" %sys.argv[0])
        sys.exit(1)
    client_val(float(val1),float(val2),float(val3))
