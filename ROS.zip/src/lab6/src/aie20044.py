#!/usr/bin/env python3
import rospy
import actionlib
from turtle_actionlib.msg import ShapeGoal,ShapeAction,ShapeResult
rospy.init_node('turtlesim_client')
client = actionlib.SimpleActionClient('turtle_shape', ShapeAction)
client.wait_for_server()
goal = ShapeGoal()
goal.edges = 4
goal.radius= 2
client.send_goal(goal)
client.wait_for_result()
print(client.get_result())
