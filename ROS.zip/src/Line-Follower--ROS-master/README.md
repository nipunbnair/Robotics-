# Line-Follower--ROS

## Steps to follow

- 1. Follow [Build Simulated ROS Robot](http://moorerobots.com/blog/) to make your own custom ROS  differental drive robot

- 2. Copy the word file and launch file present to your package

- 3. Run the python script (follower_ros.py). 

You are DONE !!!!!

## Expected Output:
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/PVIK_WIIwCY/0.jpg)](https://www.youtube.com/watch?v=PVIK_WIIwCY)
