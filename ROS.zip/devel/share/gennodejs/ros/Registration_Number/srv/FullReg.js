// Auto-generated. Do not edit!

// (in-package Registration_Number.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class FullRegRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.dept = null;
      this.num = null;
    }
    else {
      if (initObj.hasOwnProperty('dept')) {
        this.dept = initObj.dept
      }
      else {
        this.dept = '';
      }
      if (initObj.hasOwnProperty('num')) {
        this.num = initObj.num
      }
      else {
        this.num = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FullRegRequest
    // Serialize message field [dept]
    bufferOffset = _serializer.string(obj.dept, buffer, bufferOffset);
    // Serialize message field [num]
    bufferOffset = _serializer.string(obj.num, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FullRegRequest
    let len;
    let data = new FullRegRequest(null);
    // Deserialize message field [dept]
    data.dept = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [num]
    data.num = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.dept);
    length += _getByteLength(object.num);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'Registration_Number/FullRegRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a37fa0910efa57b463b35489718dd2e3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string dept
    string num
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FullRegRequest(null);
    if (msg.dept !== undefined) {
      resolved.dept = msg.dept;
    }
    else {
      resolved.dept = ''
    }

    if (msg.num !== undefined) {
      resolved.num = msg.num;
    }
    else {
      resolved.num = ''
    }

    return resolved;
    }
};

class FullRegResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.full_reg = null;
    }
    else {
      if (initObj.hasOwnProperty('full_reg')) {
        this.full_reg = initObj.full_reg
      }
      else {
        this.full_reg = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FullRegResponse
    // Serialize message field [full_reg]
    bufferOffset = _serializer.string(obj.full_reg, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FullRegResponse
    let len;
    let data = new FullRegResponse(null);
    // Deserialize message field [full_reg]
    data.full_reg = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.full_reg);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'Registration_Number/FullRegResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fee4a2cfaa604e2eeef39cee8549eace';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string full_reg
    
    
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FullRegResponse(null);
    if (msg.full_reg !== undefined) {
      resolved.full_reg = msg.full_reg;
    }
    else {
      resolved.full_reg = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: FullRegRequest,
  Response: FullRegResponse,
  md5sum() { return 'a41ad557b6dbd0da54234a10dbc4f80e'; },
  datatype() { return 'Registration_Number/FullReg'; }
};
