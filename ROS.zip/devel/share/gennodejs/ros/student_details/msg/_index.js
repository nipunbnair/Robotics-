
"use strict";

let AIE20044 = require('./AIE20044.js');

module.exports = {
  AIE20044: AIE20044,
};
