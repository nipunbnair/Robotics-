
"use strict";

let AddTwoInt = require('./AddTwoInt.js')

module.exports = {
  AddTwoInt: AddTwoInt,
};
