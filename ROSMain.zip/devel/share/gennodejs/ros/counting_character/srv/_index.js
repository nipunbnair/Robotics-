
"use strict";

let WordCount = require('./WordCount.js')

module.exports = {
  WordCount: WordCount,
};
