from ._WordCount import *
