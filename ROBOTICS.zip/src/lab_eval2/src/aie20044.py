#!/usr/bin/env python3
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import *
rospy.init_node('send_goal')
client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
client.wait_for_server()
goal = MoveBaseGoal()
goal.target_pose.header.frame_id = "map"
goal.target_pose.header.stamp = rospy.Time.now()
goal.target_pose.pose.position.x = 0
goal.target_pose.pose.position.y = 0
goal.target_pose.pose.position.z = 0
goal.target_pose.pose.orientation.x = 0
goal.target_pose.pose.orientation.y = 0
goal.target_pose.pose.orientation.z = 0
goal.target_pose.pose.orientation.w = 1
while not rospy.is_shutdown():
    print("Sending Goal Location...")
    goal.target_pose.pose.position.x =-2
    goal.target_pose.pose.position.y = 0
    client.send_goal(goal)
    client.wait_for_result()
    goal.target_pose.pose.position.x =-2
    goal.target_pose.pose.position.y = 2
    client.send_goal(goal)
    client.wait_for_result()
    goal.target_pose.pose.position.x =2
    goal.target_pose.pose.position.y = 2
    client.send_goal(goal)
    client.wait_for_result()
    goal.target_pose.pose.position.x =2
    goal.target_pose.pose.position.y = 0
    client.send_goal(goal)
    client.wait_for_result()
