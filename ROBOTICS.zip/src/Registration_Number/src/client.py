#!/usr/bin/env python3
import rospy 
from Registration_Number.srv import FullReg 
from Registration_Number.srv import FullRegResponse
import sys
def reg_no_client(x, y):
	rospy.wait_for_service('reg_no')
	try:
		print_reg = rospy.ServiceProxy('reg_no', FullReg)
		response = print_reg(x, y)
		return response.full_reg
	except rospy.ServiceException(e):
		print("Service call failed : %s" %e)



if __name__ == '__main__':
    if len(sys.argv )== 3:
    	x = str(sys.argv[1])
    	y = str(sys.argv[2])
    else:
    	print("%s [x,y]" %sys.argv[0])
    	sys.exit(1)
    print ("Requesting %s+%s" %(x, y))
    s = reg_no_client(x, y)
    print (s)
