#!/usr/bin/env python3

import rospy 
from student_details.msg import AIE20044
from random import random
def talker():
	pub = rospy.Publisher('chatter_complex',AIE20044, queue_size=10)
	rospy.init_node('Talker',anonymous=True)
	rate = rospy.Rate(1)
	while not rospy.is_shutdown():
		msg = AIE20044()
		msg.reg = "BLENU4AIE20044"
		msg.name = "Nipun B Nair"
		rospy.loginfo(msg)
		pub.publish(msg)
		rate.sleep()
if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass
