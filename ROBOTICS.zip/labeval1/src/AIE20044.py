#!/usr/bin/env python3
import rospy 
from turtlesim.srv import teleport_absolute
from turtlesim.srv import teleport_absoluteResponse
import sys
def reg_no_client(x, y, theta):
	rospy.wait_for_service('teleport_absolute')
	try:
		print_reg = rospy.ServiceProxy('teleport_absolute', teleport_absolute)
		response = print_reg(x, y, theta)
		return response.teleport_absolute
	except rospy.ServiceException(e):
		print("Service call failed : %s" %e)



if __name__ == '__main__':
    if len(sys.argv )== 4:
    	x = str(sys.argv[1])
    	y = str(sys.argv[2])
    	theta = str(sys.argv[3])
    else:
    	print("%s [x,y]" %sys.argv[0])
    	sys.exit(1)
    print ("Requesting %s+%s" %(x, y, theta))
    s = reg_no_client(x, y, theta)
    print (s)
