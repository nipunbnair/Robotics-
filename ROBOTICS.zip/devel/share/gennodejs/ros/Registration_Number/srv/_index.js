
"use strict";

let FullReg = require('./FullReg.js')

module.exports = {
  FullReg: FullReg,
};
